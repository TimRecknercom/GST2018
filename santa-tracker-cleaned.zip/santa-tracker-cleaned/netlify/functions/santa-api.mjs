// Serve Santa Tracker data in the format expected by the 2018 web app.
const GOOGLE_INFO = 'https://santa-api.appspot.com/info?client=web&language=en';
const TAKEOFF_2018 = Date.UTC(2018, 11, 24, 10, 0, 0);
const SIMULATED_YEAR = 2018;

function simulatedNow() {
  const date = new Date();
  date.setUTCFullYear(SIMULATED_YEAR);
  return date.getTime();
}

function json(body, cacheControl) {
  return new Response(JSON.stringify(body), {
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      ...(cacheControl ? { 'netlify-cdn-cache-control': cacheControl } : {}),
    },
  });
}

async function getGoogleRouteUrl() {
  const response = await fetch(`${GOOGLE_INFO}&rand=${Math.random()}`);
  if (!response.ok) throw new Error(`Santa API info request failed: ${response.status}`);

  const info = await response.json();
  const route = Array.isArray(info.route) ? info.route[0] : info.route;
  if (!route) throw new Error('No route URL in Santa API response');
  return route;
}

async function getShiftedRoute() {
  const response = await fetch(await getGoogleRouteUrl());
  if (!response.ok) throw new Error(`Santa route request failed: ${response.status}`);

  const data = await response.json();
  const destinations = Array.isArray(data.destinations) ? data.destinations : [];
  if (!destinations.length) throw new Error('Santa route is empty');

  const shift = TAKEOFF_2018 - destinations[0].departure;
  const shiftTime = (value) => (typeof value === 'number' ? value + shift : value);

  return {
    destinations: destinations.map((destination) => ({
      ...destination,
      arrival: shiftTime(destination.arrival),
      departure: shiftTime(destination.departure),
      // Panoramio was retired; an empty list prevents the legacy panel from crashing.
      details: destination.details
        ? { panoramio: [], ...destination.details }
        : destination.details,
    })),
    stream: (data.stream || []).map((item) => ({
      ...item,
      timestamp: shiftTime(item.timestamp),
    })),
  };
}

export default async function handler(request, context) {
  const url = new URL(request.url);
  const operation = url.searchParams.get('op') || 'info';

  if (operation === 'route') {
    try {
      return json(
        await getShiftedRoute(),
        'public, durable, s-maxage=86400, stale-while-revalidate=2592000, stale-if-error=2592000',
      );
    } catch (error) {
      console.error('Santa route failed:', error.message);
      return json({ destinations: [] });
    }
  }

  const requestedNow = Number(url.searchParams.get('now'));
  const previewNow =
    Number.isFinite(requestedNow) &&
    requestedNow >= TAKEOFF_2018 - 86400000 &&
    requestedNow <= TAKEOFF_2018 + 2 * 86400000
      ? requestedNow
      : null;

  const geo = context.geo || {};
  const info = {
    status: 'OK',
    now: previewNow ?? simulatedNow(),
    timeOffset: 0,
    refresh: 60000,
    route: '/.netlify/functions/santa-api?op=route&v=2',
  };

  if (Number.isFinite(geo.latitude) && Number.isFinite(geo.longitude)) {
    info.location = `${geo.latitude},${geo.longitude}`;
  }

  return json(info);
}
