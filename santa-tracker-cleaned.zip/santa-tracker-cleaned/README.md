# Santa Tracker cleanup

This project separates the Santa Tracker shell into individual files while preserving the 2018 simulation behavior.

## Entry point

Open or deploy [`index.html`](./index.html). Netlify is configured to publish the project root and route scene URLs through that entry file.

## Structure

- `index.html` — document shell and external 2018 Santa Tracker component imports
- `css/styles.css` — custom countdown styles
- `js/clock-simulation.js` — simulated 2018 clock and preview mode
- `js/api-redirect.js` — redirects legacy API requests to the local function
- `js/countdown-bar-2018.js` — local countdown fallback
- `js/unlock-all-games.js` — unlocks village activities after initialization
- `netlify.toml` — Netlify publish and fallback routing
- `netlify/functions/santa-api.mjs` — 2018-compatible data proxy

Preview the flight clock by opening `/?preview=tracker` or `/?preview=tracker&hours=4`.
